<?php
header("Location: http://buscador-cargografias.herokuapp.com/app/index.html");
// header("Location: http://localhost:8080/index.html");
// header("Location: http://genosha.com.ar");
?>
